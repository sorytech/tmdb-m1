import { SortListPipe } from './sort-list.pipe';

describe('SortListPipe', () => {
  it('create an instance', () => {
    const pipe = new SortListPipe();
    expect(pipe).toBeTruthy();
  });
});
